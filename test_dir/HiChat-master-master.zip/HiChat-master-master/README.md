HiChat
===
 
A chat application built with Node.js and socket.io.

View the live demo: http://hichat.herokuapp.com/

Features
---
* send pictures :sunrise:
* send emojis :smile:
* keyboard support :musical_keyboard:
* online users count statistic :ghost:

本地运行方法：

    命令行运行npm install
    模块下载成功后，运行node server启动服务器
    打开浏览器访问localhost:3000
